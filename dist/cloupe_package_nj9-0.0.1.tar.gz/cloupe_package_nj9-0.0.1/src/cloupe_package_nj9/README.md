# cloupe

Loupe Browser is a powerful visualization software that provides the intuitive functionality you need to explore and analyze 10x Genomics Chromium and Visium data. This is a PoC parser to read CLOUPE files using python.
